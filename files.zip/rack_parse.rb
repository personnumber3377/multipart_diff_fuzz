require 'rack'
require 'tempfile'

# Create a dummy env with required headers and input
env = {
  "CONTENT_TYPE" => "multipart/form-data; boundary=----RubyBoundary",
  "CONTENT_LENGTH" => File.size("oof.bin"),
  "rack.input" => File.open("oof.bin")
}

# Set up Rack query parser
query_parser = Rack::QueryParser.new(Rack::QueryParser::Params, 32)

# Parse multipart
parser = Rack::Multipart::Parser.new(
  env["CONTENT_TYPE"].match(/boundary=(.+)/)[1],
  Tempfile,
  File.size("oof.bin"), # buffer size
  query_parser
)

puts "filesize:"
puts File.size("oof.bin")

# Feed the input buffer
# env["rack.input"].binmode
parser.parse(env["rack.input"])
params = parser.result.params
files = parser.result.tmp_files
puts "Parsed multipart parameters:"
pp params
pp files
if params == nil
  return
end

params.each do |key, value|
  if value.respond_to?(:tempfile) && value.tempfile
    puts "[#{key}] => FILE: #{value.original_filename}, Content: #{value.tempfile.read.inspect}"
  else
    puts "[#{key}] => #{value.inspect}"
  end
end
