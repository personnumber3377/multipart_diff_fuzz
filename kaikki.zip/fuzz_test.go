package main

import (
    "bytes"
    "encoding/json"
    "io"
    // "log"
    "mime/multipart"
    "os"
    "os/exec"
    // "strings"
    "testing"
)

func LoadCorpus(f *testing.F) {
        files, _ := os.ReadDir("corpus/")
        for _, file := range files {
                if data, err := os.ReadFile("corpus/" + file.Name()); err == nil {
                        f.Add(data, []byte{})
                }
        }
}

func FuzzMultipartParser(f *testing.F) {
    f.Add([]byte("--RubyBoundary\r\nContent-Disposition: form-data; name=\"foo\"\r\n\r\nbar\r\n--RubyBoundary--\r\n"))

    f.Fuzz(func(t *testing.T, data []byte) {
        // 1. Parse with Go
        reader := multipart.NewReader(bytes.NewReader(data), "RubyBoundary")
        goParsed := map[string]string{}
        for {
            part, err := reader.NextPart()
            if err == io.EOF {
                break
            }
            if err != nil {
                return
                // break
            }

            name := part.FormName()
            val, _ := io.ReadAll(part)
            goParsed[name] = string(val)
        }
        // 2. Write to file
        if err := os.WriteFile("oof.bin", data, 0644); err != nil {
            t.Fatalf("write error: %v", err)
        }

        // 3. Run Ruby subprocess
        out, err := exec.Command("ruby", "rack_parse.rb").Output()
        if err != nil {
            return
            // t.Fatalf("ruby err: %v", err)
        }

        var rubyOutput map[string]any
        if err := json.Unmarshal(out, &rubyOutput); err != nil {
            t.Logf("Here is the thing: %s\n", out)
            t.Fatalf("ruby json error: %v", err)
        }

        // 4. Compare
        if rubyParams, ok := rubyOutput["params"].(map[string]interface{}); ok {
            for k, v := range rubyParams {
                if gv, exists := goParsed[k]; !exists || gv != v {
                    t.Fatalf("mismatch on key %s: go=%q ruby=%q", k, gv, v)
                }
            }
        }
    })
}
