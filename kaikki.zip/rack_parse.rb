require 'rack'
require 'tempfile'
require 'json'

begin
  env = {
    "CONTENT_TYPE" => "multipart/form-data; boundary=----RubyBoundary",
    "CONTENT_LENGTH" => File.size("oof.bin"),
    "rack.input" => File.open("oof.bin")
  }

  query_parser = Rack::QueryParser.new(Rack::QueryParser::Params, 32)
  parser = Rack::Multipart::Parser.new(
    env["CONTENT_TYPE"].match(/boundary=(.+)/)[1],
    Tempfile,
    File.size("oof.bin"),
    query_parser
  )

  parser.parse(env["rack.input"])
  params = parser.result.params || {}

  puts({params: params}.to_json)
rescue => e
  puts({error: e.to_s}.to_json)
end